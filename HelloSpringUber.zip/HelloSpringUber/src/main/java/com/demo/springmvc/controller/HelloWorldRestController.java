package com.demo.springmvc.controller;

import com.demo.springmvc.di.Ross;
import com.demo.springmvc.di.Tim;
import com.demo.springmvc.domain.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by tim on 2017/3/14.
 */
@RestController
public class HelloWorldRestController {

    @Autowired
    private Ross rossBean;
    @Autowired
    private Tim timBean;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String welcome() {
        return "Hello Spring Uber";
    }

    @RequestMapping(value = "/hello/{userName}", method = RequestMethod.GET)
    public Message helloMessage(@PathVariable String userName) {
        return new Message(userName, "Hello " + userName);
    }

    @RequestMapping(value = "/ross", method = RequestMethod.GET)
    public Ross helloRoss() {
        rossBean.setId(3);
        rossBean.setName("Ross 3");
        return rossBean;
    }

    @RequestMapping(value = "/tim", method = RequestMethod.GET)
    public Tim helloTim() {
        timBean.setId(6);
        timBean.setName("TIm 6");
        return timBean;
    }
}
